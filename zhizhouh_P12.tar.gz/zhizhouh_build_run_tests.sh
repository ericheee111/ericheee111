#!/bin/bash

cd catkin_ws/src/ece642rtle/student

g++ -Dtesting -o zhizhouh_student_tests zhizhouh_student_test.cpp zhizhouh_student_turtle.cpp -lcunit -std=c++11

./zhizhouh_student_tests
