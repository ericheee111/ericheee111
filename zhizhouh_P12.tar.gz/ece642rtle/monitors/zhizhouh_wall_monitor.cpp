/*
 * Code by Zhizhou He
 *
 * This monitor checks that the invariant "the turtle shall not go through 
 * walls" is not violated.
 * It keeps track of the previous position and orientaion, the current position 
 * and orientation, and also the check bump status to check the invariant.
 */

#include "monitor_interface.h"
#include <vector>
#include <algorithm>

// Keeps track of the last pose received
// moved is true if at least one pose has been received, false otherwise
static Pose last_pose;
static Orientation last_orientation;
static int count = 0;
static bool moved = false;

/**
 * @brief store bump info to vector, -1: init, 0: no bump, 1: bump
 * 
 */
typedef struct _bump_info {
    int x_target;
    int y_target;
    int x_current;
    int y_current;
    int bump;
} bump_info;

/**
 * @brief initialize bump info
 * 
 * @return bump_info 
 */
bump_info init_bump_rec() {
    bump_info bp;
    bp.x_target = -1;
    bp.y_target = -1;
    bp.x_current = -1;
    bp.y_current = -1;
    bp.bump = 0;
    return bp;
}

/* record bump info. each element means one orientation */ 
static std::vector<bump_info> bump_rec(4);

/**
 * @brief Check if the turtle moved across the wall or not check the wall before move
 * 
 * @param x1 
 * @param y1 
 * @param x2 
 * @param y2 
 */
static void checkbump(int x1, int y1, int x2, int y2) {
    int8_t bumpChecked = 0;
    for (int i = 0; i < 4; i++) {
        if (bump_rec[i].x_target == x1 && bump_rec[i].y_target == y1 && bump_rec[i].x_current == x2 && bump_rec[i].y_current == y2) {
            if (bump_rec[i].bump == 1) {
                ROS_WARN("VIOLATION: Turtle moved across the wall!");
            }
            return;
        }
        bumpChecked++;
    }
    if (bumpChecked < 4) {
        ROS_WARN("VIOLATION: Turtle didn't check all wall before move!");
    }
}

/**
 * @brief Pose interrupt handler which executes when the turtle moves
 *        It checks if the turtle moved accross the wall or not
 *        It also checks if the turtle checked the wall before move
 * 
 * @param t 
 * @param x 
 * @param y 
 * @param o 
 */
void poseInterrupt(ros::Time t, int x, int y, Orientation o)
{
    if (moved) {
        if (last_pose.x == x && last_pose.y == y) {
            return;
        }
        switch (0) {
        case EAST:
            checkbump(last_pose.x + 1, last_pose.y, last_pose.x + 1, last_pose.y + 1);
            break;
        case NORTH:
            checkbump(last_pose.x, last_pose.y + 1, last_pose.x + 1, last_pose.y + 1);
            break;
        case WEST:
            checkbump(last_pose.x, last_pose.y + 1, last_pose.x, last_pose.y);
            break;
        case SOUTH:
            checkbump(last_pose.x, last_pose.y, last_pose.x + 1, last_pose.y);
            break;
        default:
            ROS_ERROR("Invalid orientation!");
            break;
        }
        count = 0;
        /* reset the bump record array */
        std::fill(bump_rec.begin(), bump_rec.end(), init_bump_rec());
    }

    // store last Pose in memory
    last_pose.x = x;
    last_pose.y = y;

}

void tickInterrupt(ros::Time t)
{
}

void visitInterrupt(ros::Time t, int visits)
{
}

/**
 * @brief Record bump info into bump_rec vector
 * 
 * @param t 
 * @param x1 
 * @param y1 
 * @param x2 
 * @param y2 
 * @param bumped 
 */
void bumpInterrupt(ros::Time t, int x1, int y1, int x2, int y2, bool bumped)
{
    if (count >= 0 && count < 4) {
        bump_info bp = init_bump_rec();
        bp.x_target = x1;
        bp.y_target = y1;
        bp.x_current = x2;
        bp.y_current = y2;
        bp.bump = bumped;
        bump_rec[count] = bp;
    }
    count++;

    // Update this flag the first time the turtle moves
    if (!moved && count > 4) {
        moved = true;
    }
        
}

void atEndInterrupt(ros::Time t, int x, int y, bool atEnd)
{
}
