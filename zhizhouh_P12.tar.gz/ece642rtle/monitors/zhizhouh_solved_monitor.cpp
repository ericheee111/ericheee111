/*
 * Code by Zhizhou He
 *
 * This monitor checks that the invariant "If the turtle has solved the 
 * maze (atEnd(x,y)==true), it shall not move or turn" is not violated.
 * It keeps track of the previous position of the turtle and make sure the
 * turtle is at the same position when it calls atEnd(x,y).
 */

#include "monitor_interface.h"

// Keeps track of the last pose received
// moved is true if at least one pose has been received, false otherwise
static Pose last_pose;
static Orientation last_ori;
static bool atendpoint = false;
static bool moved = false;

/*
 * Whenever the turtle moves, compare the current location
 * to the previous location and throw an invariant violation
 * if the locations differ by more than 1 in Manhattan Distance.
 */
void poseInterrupt(ros::Time t, int x, int y, Orientation o)
{
    // Check that the turtle has moved before and that the Manhattan
    // distance between the positions does not exceed 1
    if (moved && atendpoint == true && (last_pose.x != x || last_pose.y != y || last_ori != o))
    {
        ROS_WARN("VIOLATION: Turtle moved after reach goal!");
    }

    // store last Pose in memory
    last_pose.x = x;
    last_pose.y = y;
    last_ori = o;

    // Update this flag the first time the turtle moves
    if (!moved)
    {
        moved = true;
    }
}

/*
 * Empty interrupt handlers beyond this point
 */

void tickInterrupt(ros::Time t)
{
}

void visitInterrupt(ros::Time t, int visits)
{
}

void bumpInterrupt(ros::Time t, int x1, int y1, int x2, int y2, bool bumped)
{
}

void atEndInterrupt(ros::Time t, int x, int y, bool atEnd)
{
    atendpoint = atEnd;
}
