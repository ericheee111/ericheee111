/*
 * Code by Zhizhou He
 *
 * This monitor checks that the invariant "the turtle shall face the 
 * direction it is moving" is not violated.
 * It keeps track of the previous position and orientation of the turtle and 
 * compares it to the current position and orientation to check the invariant.
 */

#include "monitor_interface.h"

// Keeps track of the last pose received
// moved is true if at least one pose has been received, false otherwise
static Pose last_pose;
static bool moved = false;

/**
 * @brief Check if the turtle movement is valid
 * 
 * @param last_pose 
 * @param x 
 * @param y 
 * @param o 
 * @return true 
 * @return false 
 */
bool moveValid(Pose last_pose, int x, int y, Orientation o)
{   
    bool valid = false;
    if (last_pose.x == x - 1 && last_pose.y == y && o != EAST)
    {
        valid = true;
    }
    else if (last_pose.x == x + 1 && last_pose.y == y && o != WEST)
    {
        valid = true;
    }
    else if (last_pose.x == x && last_pose.y == y + 1 && o != NORTH)
    {
        valid = true;
    }
    else if (last_pose.x == x && last_pose.y == y - 1 && o != SOUTH)
    {
        valid = true;
    }
    
    return valid;
}

/*
 * Whenever the turtle moves, compare the current location
 * to the previous location and throw an invariant violation
 * if the locations differ by more than 1 in Manhattan Distance.
 */
void poseInterrupt(ros::Time t, int x, int y, Orientation o)
{
    // Check that the turtle has moved before and move is valid
    if (moved) {
        if (moveValid(last_pose, x, y, o)) {
            ROS_WARN("VIOLATION: Turtle is not facing the right direction!");
        }
    }

    // store last Pose in memory
    last_pose.x = x;
    last_pose.y = y;

    // Update this flag the first time the turtle moves
    if (!moved)
    {
        moved = true;
    }
}

/*
 * Empty interrupt handlers beyond this point
 */

void tickInterrupt(ros::Time t)
{
}

void visitInterrupt(ros::Time t, int visits)
{
}

void bumpInterrupt(ros::Time t, int x1, int y1, int x2, int y2, bool bumped)
{
}

void atEndInterrupt(ros::Time t, int x, int y, bool atEnd)
{
}
