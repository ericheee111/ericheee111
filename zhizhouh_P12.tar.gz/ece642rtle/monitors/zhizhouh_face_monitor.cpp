/*
 * Code by Zhizhou He
 *
 * This monitor checks that the invariant "for any call to bumped(x1,y1,x2,y2),
 * the turtle shall be facing the wall segment with endpoints (x1,y1) and (x2,y2)."
 * is not violated.
 * It keeps track of the wall facing and the wall called bump on
 */

#include "monitor_interface.h"

// wall information
struct Wall
{
    int32_t x1;
    int32_t y1;
    int32_t x2;
    int32_t y2;

    inline bool operator!=(const Wall &other) const
    {
        return (x1 != other.x1 || y1 != other.y1 || x2 != other.x2 || y2 != other.y2);
    }
};

static Wall bump; // the wall used for bump
static Wall face; // the wall facing
// static Orientation orient = (Orientation)-1;
static bool moved = false;

/*
 * Whenever the turtle moves, compare the current location
 * to the previous location and throw an invariant violation
 * if the locations differ by more than 1 in Manhattan Distance.
 */
void poseInterrupt(ros::Time t, int32_t x, int32_t y, Orientation o)
{
    switch (o)
    {
    case WEST:
        face = {x, y + 1, x, y}; 
        break;
    case NORTH:
        face = {x, y, x + 1, y};
        break;
    case EAST:
        face = {x + 1, y, x + 1, y + 1};
        break;
    case SOUTH:
        face = {x + 1, y + 1, x , y + 1};
        break;
    default:
        ROS_ERROR("Invalid orientation!");
        break;
    }
}

/*
 * Empty interrupt handlers beyond this point
 */
void tickInterrupt(ros::Time t)
{
}

void visitInterrupt(ros::Time t, int32_t visits)
{
}

/**
 * @brief bump Interrupt handler, check if the bump wall is the same as the facing wall
 *
 * @param t
 * @param x1
 * @param y1
 * @param x2
 * @param y2
 * @param bumped
 */
void bumpInterrupt(ros::Time t, int32_t x1, int32_t y1, int32_t x2, int32_t y2, bool bumped)
{
    bump = {x1, y1, x2, y2};
    
    if (moved == true && bump != face)
    {
        ROS_WARN("VIOLATION: Called bump on a wall that's not facing!; x1: %d : %d, y1: %d : %d, x2: %d : %d, y2: %d : %d", x1, face.x1, y1, face.y1, x2, face.x2, y2, face.y2);
    }
}

void atEndInterrupt(ros::Time t, int32_t x, int32_t y, bool atEnd)
{
}
