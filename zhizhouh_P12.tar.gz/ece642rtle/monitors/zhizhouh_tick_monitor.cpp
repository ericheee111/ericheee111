/*
 * Code by Zhizhou He
 *
 * This monitor checks that the invariant "between calls to tickInterrupt, 
 * there shall be at most one call to each of poseInterrupt, visitsInterrupt, 
 * and bumpInterrupt." is not violated.
 * It keeps track of the calls of pose, tick, visit, bump interrupt 
 * handlers to make sure there is no extra calls to the handlers.
 */

#include "monitor_interface.h"

// keep track of the calls to the interrupt functions
static int pose_count = 0;
static int visit_count = 0;
static int bump_count = 0;

/*
 * This interrupt occurs when a call to moveTurtle returns.
 * count the number of pose interrupts called between tick interrupts
 */
void poseInterrupt(ros::Time t, int x, int y, Orientation o) {
    pose_count++;
    if (pose_count > 1) {
        ROS_WARN("VIOLATION: Called poseInterrupt more than once between calls to tickInterrupt!");
    }

}

/*
 * This interrupt occurs when a call to moveTurtle returns.
 * It can be used to keep track of what messages are being sent in a
 * single call to moveTurtle.
 */
void tickInterrupt(ros::Time t) {
    // reset the interrupt call counts
    pose_count = 0;
    visit_count = 0;
    bump_count = 0;
}

/*
 * This interrupt occurs when visits sent.
 * count the number of visits interrupts called between tick interrupts
 */
void visitInterrupt(ros::Time t, int visits) {
    visit_count++;
    if (visit_count > 1) {
        ROS_WARN("VIOLATION: Called visitsInterrupt more than once between calls to tickInterrupt!");
    }
}

/**
 * This interrupt occurs when bump request.
 * count the number of bump interrupts called between tick interrupts
 */
void bumpInterrupt(ros::Time t, int x1, int y1, int x2, int y2, bool bumped) {
    bump_count++;
    if (bump_count > 1) {
        ROS_WARN("VIOLATION: Called bumpInterrupt more than once between calls to tickInterrupt!");
    }
}

void atEndInterrupt(ros::Time t, int x, int y, bool atEnd) {
}
