/*
 * 18-642 Unit Testing Example
 * Example code by Milda Zizyte
 * This code exercises Transitions T1 and T2 of the Project 8
 * dummy turtle statechart. It uses the CUnit framework (cunit.sourceforge.net)
 */

#include "zhizhouh_student_mock.h"
#include <CUnit/Basic.h>

/*  ----- test calc_path(), the compute function -----  */
// test_ct1() tests diff = 0, no turn, turtle already facing target orientation
// test for transition T9
void test_ct1()
{
    std::pair<turtleMove, int32_t> return_move = calc_path(UP, UP);

    CU_ASSERT_EQUAL(return_move.first, MOVE);
    CU_ASSERT_EQUAL(return_move.second, 0);
}

// test_ct2() tests diff = -2, turn left, turtle needs to turn left twice to face target orientation
// test for transition T10
void test_ct2()
{
    std::pair<turtleMove, int32_t> return_move = calc_path(DOWN, UP);

    CU_ASSERT_EQUAL(return_move.first, TURN_LEFT);
    CU_ASSERT_EQUAL(return_move.second, 2);
}

// test_ct3() tests diff = 2, turn right, turtle needs to turn right twice to face target orientation
// test for transition T5
void test_ct3()
{
    std::pair<turtleMove, int32_t> return_move = calc_path(UP, DOWN);

    CU_ASSERT_EQUAL(return_move.first, TURN_RIGHT);
    CU_ASSERT_EQUAL(return_move.second, 2);
}

// test_ct4() tests diff = -3, turn left, turtle needs to turn right once to face target orientation
// test for transition T10
void test_ct4()
{
    std::pair<turtleMove, int32_t> return_move = calc_path(LEFT, UP);

    CU_ASSERT_EQUAL(return_move.first, TURN_RIGHT);
    CU_ASSERT_EQUAL(return_move.second, 1);
}

// test_ct5() tests diff = 3, turn right, turtle needs to turn left once to face target orientation
// test for transition T5
void test_ct5()
{
    std::pair<turtleMove, int32_t> return_move = calc_path(UP, LEFT);

    CU_ASSERT_EQUAL(return_move.first, TURN_LEFT);
    CU_ASSERT_EQUAL(return_move.second, 1);
}

/*  ----- test studentTurtleStep1() -----  */
// test_t15() tests transition T15, input: end = true, targetOri = UP, currOri = UP, turtleState = INIT1
void test_t15()
{
    int32_t turtleState = INIT1;
    turtleMove return_move = studentTurtleStep1(true, UP, UP, &turtleState);

    CU_ASSERT_EQUAL(return_move, idle);
    CU_ASSERT_EQUAL(turtleState, Goal);
}

// test_t1() tests transition T1, input: end = false, targetOri = UP, currOri = UP, turtleState = INIT1
void test_t1()
{
    int32_t turtleState = INIT1;
    turtleMove return_move = studentTurtleStep1(false, UP, UP, &turtleState);

    CU_ASSERT_EQUAL(return_move, TURN_RIGHT);
    CU_ASSERT_EQUAL(turtleState, RIGHT3);
}

// test_t2() tests transition T2, input: end = false, targetOri = UP, currOri = DOWN, turtleState = RIGHT3
void test_t2()
{
    int32_t turtleState = RIGHT3;
    turtleMove return_move = studentTurtleStep1(false, UP, LEFT, &turtleState);

    CU_ASSERT_EQUAL(return_move, TURN_RIGHT);
    CU_ASSERT_EQUAL(turtleState, RIGHT2);
}

// test_t3() tests transition T3, input: end = false, targetOri = UP, currOri = DOWN, turtleState = RIGHT2
void test_t3()
{
    int32_t turtleState = RIGHT2;
    turtleMove return_move = studentTurtleStep1(false, RIGHT, DOWN, &turtleState);

    CU_ASSERT_EQUAL(return_move, TURN_RIGHT);
    CU_ASSERT_EQUAL(turtleState, RIGHT1);
}

// test_t4() tests transition T4, input: end = false, targetOri = UP, currOri = DOWN, turtleState = RIGHT1
void test_t4()
{
    int32_t turtleState = RIGHT1;
    turtleMove return_move = studentTurtleStep1(false, DOWN, DOWN, &turtleState);

    CU_ASSERT_EQUAL(return_move, TURN_RIGHT);
    CU_ASSERT_EQUAL(turtleState, CALC_PATH);
}

// test_t5_t6_t7_t8() tests transition T5 T6 T7 T8
void test_t5_t6_t7_t8()
{
    int32_t turtleState = CALC_PATH;
    turtleMove return_move = studentTurtleStep1(false, UP, RIGHT, &turtleState); // T5
    // turnNeed = 1
    CU_ASSERT_EQUAL(return_move, idle);
    CU_ASSERT_EQUAL(turtleState, RIGHTturns);

    return_move = studentTurtleStep1(false, UP, RIGHT, &turtleState); // T6
    // turnNeed = 1
    CU_ASSERT_EQUAL(return_move, idle);
    CU_ASSERT_EQUAL(turtleState, Turn_Right);

    return_move = studentTurtleStep1(false, UP, RIGHT, &turtleState); // T7
    // turned, turnNeed = 0
    CU_ASSERT_EQUAL(return_move, TURN_RIGHT);
    CU_ASSERT_EQUAL(turtleState, RIGHTturns);

    return_move = studentTurtleStep1(false, RIGHT, RIGHT, &turtleState); // T8
    CU_ASSERT_EQUAL(return_move, idle);
    CU_ASSERT_EQUAL(turtleState, MOVEstate);
}

// test_t10_t11_t12_t13() tests transition T10 T11 T12 T13
void test_t10_t11_t12_t13()
{
    int32_t turtleState = CALC_PATH;
    turtleMove return_move = studentTurtleStep1(false, RIGHT, UP, &turtleState); // T10
    // turnNeed = 1
    CU_ASSERT_EQUAL(return_move, idle);
    CU_ASSERT_EQUAL(turtleState, LEFTturns);

    return_move = studentTurtleStep1(false, RIGHT, UP, &turtleState); // T11
    // turnNeed = 1
    CU_ASSERT_EQUAL(return_move, idle);
    CU_ASSERT_EQUAL(turtleState, Turn_Left);

    return_move = studentTurtleStep1(false, RIGHT, UP, &turtleState); // T12
    // turned, turnNeed = 0
    CU_ASSERT_EQUAL(return_move, TURN_LEFT);
    CU_ASSERT_EQUAL(turtleState, LEFTturns);

    return_move = studentTurtleStep1(false, UP, UP, &turtleState); // T13
    CU_ASSERT_EQUAL(return_move, idle);
    CU_ASSERT_EQUAL(turtleState, MOVEstate);
}

// test_t9_t14() tests transition T9 T14
void test_t9_t14()
{
    int32_t turtleState = CALC_PATH;
    turtleMove return_move = studentTurtleStep1(false, UP, UP, &turtleState); // T9
    // already facing target orientation
    CU_ASSERT_EQUAL(return_move, idle);
    CU_ASSERT_EQUAL(turtleState, MOVEstate);

    return_move = studentTurtleStep1(false, UP, UP, &turtleState); // T14
    CU_ASSERT_EQUAL(return_move, MOVE);
    CU_ASSERT_EQUAL(turtleState, INIT1);
}

// test error handling
void test_error()
{
    int32_t turtleState = ErrorTurtleStateDefault;
    turtleMove return_move = studentTurtleStep1(false, UP, UP, &turtleState);
    CU_ASSERT_EQUAL(return_move, ErrorMoveDefault);
    CU_ASSERT_EQUAL(turtleState, ErrorTurtleStateDefault);
}

/*  ----- test recVisit() -----  */
// test_rv1() tests recVisit()
void test_rv1()
{
    int32_t newOrientation = UP;

    // go up
    int32_t return_visit = recVisit(newOrientation, true);
    CU_ASSERT_EQUAL(return_visit, 1);

    newOrientation = RIGHT;

    // go right
    return_visit = recVisit(newOrientation, true);
    CU_ASSERT_EQUAL(return_visit, 1);

    newOrientation = DOWN;

    // go down
    return_visit = recVisit(newOrientation, true);
    CU_ASSERT_EQUAL(return_visit, 1);

    newOrientation = LEFT;

    // go left
    return_visit = recVisit(newOrientation, true);
    CU_ASSERT_EQUAL(return_visit, 1);

    newOrientation = UP;

    // go up
    return_visit = recVisit(newOrientation, true);
    CU_ASSERT_EQUAL(return_visit, 2);

    // peek up, no move
    return_visit = recVisit(newOrientation, false);
    CU_ASSERT_EQUAL(return_visit, 0);

    newOrientation = RIGHT;

    // peek right, no move
    return_visit = recVisit(newOrientation, false);
    CU_ASSERT_EQUAL(return_visit, 1);

    newOrientation = DOWN;

    // peek down, no move
    return_visit = recVisit(newOrientation, false);
    CU_ASSERT_EQUAL(return_visit, 1);

    newOrientation = LEFT;

    // go left
    return_visit = recVisit(newOrientation, true);
    CU_ASSERT_EQUAL(return_visit, 1);

    // peek left, no move
    return_visit = recVisit(newOrientation, false);
    CU_ASSERT_EQUAL(return_visit, 0);

    newOrientation = RIGHT;

    // peek right, no move
    return_visit = recVisit(newOrientation, false);
    CU_ASSERT_EQUAL(return_visit, 2);
}

// test invalid orientation
void test_ori_error()
{
    int32_t newOrientation = 5; // valid orientation: 0, 1, 2, 3

    // go up
    int32_t return_visit = recVisit(newOrientation, true);
    CU_ASSERT_EQUAL(return_visit, -1); // invalid orientation, return -1
    CU_ASSERT_EQUAL(newOrientation, ErrorOrientationDefault);
}

int init()
{
    // Any test initialization code goes here
    return 0;
}

int cleanup()
{
    // Any test cleanup code goes here
    return 0;
}

void ROS_ERROR(std::string e)
{
    std::cout << e << std::endl;
}

int main()
{
    CU_pSuite pSuite = NULL;

    /* initialize the CUnit test registry */
    if (CUE_SUCCESS != CU_initialize_registry())
        return CU_get_error();

    /* add a suite to the registry */
    pSuite = CU_add_suite("Suite_1", init, cleanup);
    if (NULL == pSuite)
    {
        CU_cleanup_registry();
        return CU_get_error();
    }

    /* add the tests to the suite */
    if ((NULL == CU_add_test(pSuite, "test of calc_path(), orientation diff = 0", test_ct1)) ||
        (NULL == CU_add_test(pSuite, "test of calc_path(), orientation diff = -2", test_ct2)) ||
        (NULL == CU_add_test(pSuite, "test of calc_path(), orientation diff = 2", test_ct3)) ||
        (NULL == CU_add_test(pSuite, "test of calc_path(), orientation diff = -3", test_ct4)) ||
        (NULL == CU_add_test(pSuite, "test of calc_path(), orientation diff = 3", test_ct5)) ||
        (NULL == CU_add_test(pSuite, "test of transition T15", test_t15)) ||
        (NULL == CU_add_test(pSuite, "test of transition T5 T6 T7 T8", test_t5_t6_t7_t8)) ||
        (NULL == CU_add_test(pSuite, "test of transition T10 T11 T12 T13", test_t10_t11_t12_t13)) ||
        (NULL == CU_add_test(pSuite, "test of transition T9 T14", test_t9_t14)) ||
        (NULL == CU_add_test(pSuite, "test of invalid state error handling", test_error)) ||
        (NULL == CU_add_test(pSuite, "test of invalid orientation error handling", test_ori_error)) ||
        (NULL == CU_add_test(pSuite, "test of record visit when move or peek", test_rv1)))
    {
        CU_cleanup_registry();
        return CU_get_error();
    }

    /* Run all tests using the CUnit Basic interface */
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();
    return CU_get_error();

    return 0;
}