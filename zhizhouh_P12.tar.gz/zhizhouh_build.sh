#!/bin/bash

#rm -rf catkin_ws/src/ece642rtle
#rm -rf catkin_ws/src/proj1
#rm -rf catkin_ws/src/beginner_tutorials
#cp -r ece642rtle/ catkin_ws/src/
#cp -r ece642rtle catkin_ws/src/ece642rtle

sleep 1

cd ~/catkin_ws
catkin_make -DCATKIN_WHITELIST_PACKAGES="ece642rtle"

sleep 1
catkin_make

catkin_make ece642rtle_student

catkin_make ece642rtle_logging_monitor

catkin_make ece642rtle_step_monitor

catkin_make ece642rtle_turn_monitor

catkin_make ece642rtle_tick_monitor

catkin_make ece642rtle_forward_monitor

catkin_make ece642rtle_wall_monitor

catkin_make ece642rtle_face_monitor

catkin_make ece642rtle_solved_monitor

catkin_make ece642rtle_atend_monitor

cd ..

./zhizhouh_build_run_tests.sh
