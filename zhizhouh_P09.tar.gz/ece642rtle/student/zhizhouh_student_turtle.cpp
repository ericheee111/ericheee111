/*
 * Originally by Philip Koopman (koopman@cmu.edu)
 * and Milda Zizyte (milda@cmu.edu)
 *
 * STUDENT NAME: Zhizhou He
 * ANDREW ID: zhizhouh
 * LAST UPDATE: 10/28/2023
 *
 * This file is an algorithm to solve the ece642rtle maze
 * using the right-hand rule. The code is intentionaly right obfuscated.
 *
 */


#ifdef testing
#include "zhizhouh_student_mock.h"
#endif
#ifndef testing
#include "student.h"
#include "ros/ros.h"
#endif

/*
Purpose: Calculate how to turn to the target orientation.
Input: targetOri, currOri.
Output: std::pair<turtleMove, int>
Saved Internal State: none
*/
std::pair<turtleMove, int32_t> calc_path(int32_t targetOri, int32_t currOri)
{
    int32_t offset = 4;
    int32_t diff = targetOri - currOri;
    if (diff < -2)
    {
        diff += offset;
    }
    else if (diff > 2)
    {
        diff -= offset;
    }

    if (diff < 0)
    {
        return {TURN_LEFT, abs(diff)};
    }
    else if (diff > 0)
    {
        return {TURN_RIGHT, diff};
    }
    else
    {
        return {MOVE, 0};
    }
}

/*
Purpose: Turtle determine next step.
Input: bumped, end, currState
Output: turtleMove (indicates the next step)
Saved Internal State: turtleState
*/
turtleMove studentTurtleStep1(bool end, int32_t targetOri, int32_t currOri, int32_t *turtleState)
{
    turtleMove nextMove = idle;
    static int32_t turnNeed = -1;
    std::pair<turtleMove, int32_t> path;
    if (end == true)
    {
        *turtleState = Goal;            
    }
    switch (*turtleState)
    {
    case INIT1:                         // S1
        *turtleState = RIGHT3;          // T1
        nextMove = TURN_RIGHT;
        break;
    case RIGHT3:                        // S2
        *turtleState = RIGHT2;          // T2
        nextMove = TURN_RIGHT;
        break;
    case Goal:                          
        nextMove = idle;
        break;
    case RIGHT2:                        // S4
        *turtleState = RIGHT1;          // T3
        nextMove = TURN_RIGHT;
        break;
    case RIGHT1:                        // S5
        *turtleState = CALC_PATH;       // T4
        nextMove = TURN_RIGHT;
        break;
    case CALC_PATH:                     // S6
    {
        path = calc_path(targetOri, currOri);
        nextMove = path.first;
        turnNeed = path.second;
        if (nextMove == MOVE)
        {
            *turtleState = MOVEstate;   // T9
        }
        else if (nextMove == TURN_LEFT)
        {
            *turtleState = LEFTturns;   // T10
        }
        else if (nextMove == TURN_RIGHT)
        {
            *turtleState = RIGHTturns;  // T5
        }
        nextMove = idle;
        break;
    }
    case RIGHTturns:                    // S7
    {
        if (turnNeed > 0)
        {
            nextMove = idle;
            *turtleState = Turn_Right;  // T6
            turnNeed--;
        }
        else if (turnNeed == 0)
        {
            nextMove = idle;
            *turtleState = MOVEstate;   // T8
        }
        break;
    }
    case MOVEstate:                     // S8
    {
        nextMove = MOVE;
        *turtleState = INIT1;           // T14
        break;
    }
    case LEFTturns:                     // S9
    {
        if (turnNeed > 0)
        {
            nextMove = idle;
            *turtleState = Turn_Left;   // T11
            turnNeed--;
        }
        else if (turnNeed == 0)
        {
            nextMove = idle;
            *turtleState = MOVEstate;   // T13
        }
        break;
    }
    case Turn_Right:                // S10
    {
        nextMove = TURN_RIGHT;
        *turtleState = RIGHTturns;  // T7
        break;
    }
    case Turn_Left:                 // S11
    {
        nextMove = TURN_LEFT;
        *turtleState = LEFTturns;   // T12
        break;
    }
    default:
        *turtleState = ErrorTurtleStateDefault;
        nextMove = ErrorMoveDefault;
        ROS_ERROR("ERROR!! Invalid State.");
        break;
    }

    return nextMove;
}

/*
Purpose: Record the visits.
Input: newOrientation.
Output: visited times of the current location.
Saved Internal State: None
*/
int32_t recVisit(int32_t &newOrientation, bool move)
{
    const int32_t arraySize = 23;
    const int32_t initLocation = 11;
    static int32_t visited[arraySize][arraySize] = {0};
    static int32_t i = initLocation, j = initLocation;
    int32_t peeki = i, peekj = j;

    switch (newOrientation)
    {
    case DOWN:
        peekj--;
        if (move == true)
        {
            j--;
        }
        break;
    case RIGHT:
        peeki++;
        if (move == true)
        {
            i++;
        }
        break;
    case UP:
        peekj++;
        if (move == true)
        {
            j++;
        }
        break;
    case LEFT:
        peeki--;
        if (move == true)
        {
            i--;
        }
        break;
    default:
        newOrientation = ErrorOrientationDefault;

        ROS_ERROR("ERROR!! Invalid Orientation.");
        return -1;
        break;
    }
    if (move == true)
    {
        visited[i][j]++;
        return visited[i][j];
    }
    return visited[peeki][peekj];
}
