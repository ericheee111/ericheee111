/*
 * Originally by Philip Koopman (koopman@cmu.edu)
 * and Milda Zizyte (milda@cmu.edu)
 *
 * STUDENT NAME: Zhizhou He
 * ANDREW ID: zhizhouh
 * LAST UPDATE: 10/28/2023
 *
 * This file keeps track of where the turtle is in the maze
 * and updates the location when the turtle is moved. It shall not
 * contain the maze solving logic/algorithm.
 *
 * This file is used along with student_turtle.cpp. student_turtle.cpp shall
 * contain the maze solving logic/algorithm and shall not make use of the
 * absolute coordinates or orientation of the turtle.
 *
 * This file shall call studentTurtleStep(..) in student_turtle.cpp to determine
 * the next move the turtle will make, and shall use translatePos(..) and
 * translateOrnt(..) to translate this move into absolute coordinates
 * to display the turtle.
 *
 */

#include "student.h"

/*
Purpose: Set destination location and check if there is a wall on the way to the destination.
Input: pos_, newOrientation.
Output: true if there is a wall on the way to the destination, false if there is no wall on the way to the destination.
Saved Internal State: none
*/
bool checkWall(QPointF &pos_, int &newOrientation)
{
    std::pair<int, int> currLocation, destLocation;
    currLocation = {pos_.x(), pos_.y()};
    destLocation = {pos_.x(), pos_.y()};

    switch (newOrientation)
    {
    case UP:
        return bumped(currLocation.first, currLocation.second, destLocation.first, destLocation.second + 1);
        break;
    case RIGHT:
        return bumped(currLocation.first, currLocation.second, destLocation.first + 1, destLocation.second);
        break;
    case DOWN:
        return bumped(currLocation.first + 1, currLocation.second, destLocation.first + 1, destLocation.second + 1);
        break;
    case LEFT:
        return bumped(currLocation.first, currLocation.second + 1, destLocation.first + 1, destLocation.second + 1);
        break;
    default:
        ROS_ERROR("ERROR!! Orientation Not Valid.");
        break;
    }
    return true;
}

/*
Purpose: This procedure takes the current turtle position and orientation and returns if changes accepted.
Input: pos_, newOrientation.
Output: true if accept changes, false if do not accept changes
Saved Internal State: currState, turtleState
*/
bool moveTurtle(QPointF &pos_, int &newOrientation)
{
    static const uint8_t TIMEOUT = 20; // bigger number slows down simulation so you can see what's happening
    // static int currState = INIT, 
    static int waitTime = 0, turtleState = INIT1;
    static int lowestVisitOri = -1, lowestVisit = 20;
    bool endCell = false;
    // ROS_INFO("Turtle update Called  w=%f", waitTime);

    if (waitTime == 0)
    {
        // check if the turtle is at the end point
        endCell = atend((int)pos_.x(), (int)pos_.y());
        turtleMove nextMove = studentTurtleStep1(endCell, lowestVisitOri, (int)newOrientation, &turtleState);
        newOrientation = translateOrnt(newOrientation, (int) nextMove);
        bool bumped = checkWall(pos_, newOrientation);
        int currVisit = recVisit(newOrientation, false);
        ROS_INFO("currVisit=%d, lowestV = %d, bump=%d", currVisit, lowestVisit, bumped);
        if (bumped == false && currVisit < lowestVisit)
        {
            lowestVisit = currVisit;
            lowestVisitOri = (int)newOrientation;
        }
        if (nextMove == MOVE && endCell == false)
        {
            pos_ = translatePos(pos_, newOrientation, nextMove);
            lowestVisit = 20;
            lowestVisitOri = -1;
        }

        // output the current state and orientation
        // ROS_INFO("Orientation=%f  STATE=%f", newOrientation, currState);
    }

    // if the turtle is at the end point, stop the simulation
    if (endCell == true)
    {
        return false;
    }
    // if the timer run to 0, reset the timer, else decrease the timer
    if (waitTime == 0)
    {
        waitTime = TIMEOUT;
    }
    else
    {
        waitTime -= (int)1;
    }

    if (waitTime == TIMEOUT)
    {
        return true;
    }
    return false;
}

/*
Purpose: Change turtle's absolute position.
Input: pos_, orientation, nextMove.
Output: pos_ (the new position)
Saved Internal State: none
*/
QPointF translatePos(QPointF pos_, int orientation, int nextMove)
{
    if (nextMove == MOVE)
    {
        switch (orientation)
        {
        case UP:
            pos_.setX(pos_.x() - 1);
            break;
        case RIGHT:
            pos_.setY(pos_.y() - 1);
            break;
        case DOWN:
            pos_.setX(pos_.x() + 1);
            break;
        case LEFT:
            pos_.setY(pos_.y() + 1);
            break;
        default:
            ROS_ERROR("ERROR!! Orientation Not Valid.");
            break;
        }
        displayVisits(recVisit(orientation, true));
    }
    return pos_;
}

/*
Purpose: Change turtle's absolute orientation.
Input: orientation, nextMove.
Output: orientation (the new orientation)
Saved Internal State: none
*/
int translateOrnt(int orientation, int nextMove)
{
    switch (nextMove)
    {
    case TURN_LEFT:
        if (orientation == UP)
        {
            orientation = LEFT;
        }
        else
        {
            orientation = orientation - (int)1;
        }
        break;
    case TURN_RIGHT:
        if (orientation == LEFT)
        {
            orientation = UP;
        }
        else
        {
            orientation = orientation + (int)1;
        }
        break;
    case MOVE:
        return orientation;
        break;
    case idle:
        return orientation;
        break;
    default:
        ROS_ERROR("ERROR!! Orientation Not Valid.");
        break;
    }
    return orientation;
}
