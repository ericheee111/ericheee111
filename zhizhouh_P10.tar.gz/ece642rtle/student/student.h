#include <ros/ros.h>
#include <boost/bind.hpp>
#include <ece642rtle/timeInt8.h>
#include <std_msgs/Empty.h>
#include <ece642rtle/RTIbump.h>
#include <ece642rtle/RTIatend.h>
#include <ece642rtle/PoseOrntBundle.h>
#include <ece642rtle/bumpEcho.h>
#include <ece642rtle/aendEcho.h>
#include <QPointF>
#include <cstdlib>

bool bumped(int32_t x1, int32_t y1, int32_t x2, int32_t y2);
bool atend(int32_t x, int32_t y);
void displayVisits(int32_t visits);
bool moveTurtle(QPointF &pos_, int32_t &newOrientation);

enum state : int32_t
{
    INIT,
    turnRIGHT,
    turnLEFT,
    ErrorStateDefault
};

enum turtlestate : int32_t
{
    INIT1,
    RIGHT3,
    Goal,
    RIGHT2,
    RIGHT1,
    CALC_PATH,
    RIGHTturns,
    MOVEstate,
    LEFTturns,
    Turn_Right,
    Turn_Left,
    ErrorTurtleStateDefault
};

enum orientation : int32_t
{
    LEFT,
    DOWN,
    RIGHT,
    UP,
    ErrorOrientationDefault
};

enum turtleMove : int32_t
{
    MOVE,
    TURN_LEFT,
    TURN_RIGHT,
    idle,
    ErrorMoveDefault
};
QPointF translatePos(QPointF pos_, int32_t orientation, int32_t nextMove);
int32_t translateOrnt(int32_t orientation, int32_t nextMove);
turtleMove studentTurtleStep1(bool end, int32_t targetOri, int32_t currOri, int32_t *turtleState);
int32_t recVisit(int32_t &newOrientation, bool move);
