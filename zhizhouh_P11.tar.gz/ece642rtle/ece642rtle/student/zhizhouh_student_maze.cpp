/*
 * Originally by Philip Koopman (koopman@cmu.edu)
 * and Milda Zizyte (milda@cmu.edu)
 *
 * STUDENT NAME: Zhizhou He
 * ANDREW ID: zhizhouh
 * LAST UPDATE: 10/28/2023
 *
 * This file keeps track of where the turtle is in the maze
 * and updates the location when the turtle is moved. It shall not
 * contain the maze solving logic/algorithm.
 *
 * This file is used along with student_turtle.cpp. student_turtle.cpp shall
 * contain the maze solving logic/algorithm and shall not make use of the
 * absolute coordinates or orientation of the turtle.
 *
 * This file shall call studentTurtleStep(..) in student_turtle.cpp to determine
 * the next move the turtle will make, and shall use translatePos(..) and
 * translateOrnt(..) to translate this move into absolute coordinates
 * to display the turtle.
 *
 */


#ifdef testing
#include "zhizhouh_student_mock.h"
#endif
#ifndef testing
#include "student.h"
#include "ros/ros.h"
#endif


/*
Purpose: Set destination location and check if there is a wall on the way to the destination.
Input: pos_, newOrientation.
Output: true if there is a wall on the way to the destination, false if there is no wall on the way to the destination.
Saved Internal State: none
*/
bool checkWall(QPointF &pos_, int32_t &newOrientation)
{
    std::pair<int32_t, int32_t> currLocation, destLocation;
    currLocation = {(int32_t)pos_.x(), (int32_t)pos_.y()};
    destLocation = {(int32_t)pos_.x(), (int32_t)pos_.y()};

    switch (newOrientation)
    {
    case LEFT:
        return bumped(currLocation.first, currLocation.second, destLocation.first, destLocation.second + 1);
        break;
    case DOWN:
        return bumped(currLocation.first, currLocation.second, destLocation.first + 1, destLocation.second);
        break;
    case RIGHT:
        return bumped(currLocation.first + 1, currLocation.second, destLocation.first + 1, destLocation.second + 1);
        break;
    case UP:
        return bumped(currLocation.first, currLocation.second + 1, destLocation.first + 1, destLocation.second + 1);
        break;
    default:
        ROS_ERROR("ERROR!! Orientation Not Valid.");
        break;
    }
    return true;
}

/*
Purpose: This procedure takes the current turtle position and orientation and returns if changes accepted.
Input: pos_, newOrientation.
Output: true if accept changes, false if do not accept changes
Saved Internal State: currState, turtleState
*/
bool moveTurtle(QPointF &pos_, int32_t &newOrientation)
{
    static const uint8_t TIMEOUT = 10; // bigger number slows down simulation so you can see what's happening
    static int32_t waitTime = 0, turtleState = INIT1;
    static int32_t lowestVisitOri = -1, lowestVisit = 20;
    bool endCell = false;
    // ROS_INFO("Turtle update Called  w=%f", waitTime);

    if (waitTime == 0)
    {
        // check if the turtle is at the end point
        endCell = atend((int32_t)pos_.x(), (int32_t)pos_.y());
        turtleMove nextMove = studentTurtleStep1(endCell, lowestVisitOri, (int32_t)newOrientation, &turtleState);
        newOrientation = translateOrnt(newOrientation, (int32_t) nextMove);
        bool bumped = checkWall(pos_, newOrientation);
        int32_t currVisit = recVisit(newOrientation, false);
        ROS_INFO("currVisit=%d, lowestV = %d, bump=%d", currVisit, lowestVisit, bumped);
        if (bumped == false && currVisit < lowestVisit)
        {
            lowestVisit = currVisit;
            lowestVisitOri = (int32_t)newOrientation;
        }
        if (nextMove == MOVE && endCell == false)
        {
            pos_ = translatePos(pos_, newOrientation, nextMove);
            lowestVisit = 20;
            lowestVisitOri = -1;
        }

        // output the current state and orientation
        // ROS_INFO("Orientation=%f  STATE=%f", newOrientation, currState);
    }

    // if the turtle is at the end point, stop the simulation
    if (endCell == true)
    {
        return false;
    }
    // if the timer run to 0, reset the timer, else decrease the timer
    if (waitTime == 0)
    {
        waitTime = TIMEOUT;
    }
    else
    {
        waitTime -= (int32_t)1;
    }

    if (waitTime == TIMEOUT)
    {
        return true;
    }
    return false;
}

/*
Purpose: Change turtle's absolute position.
Input: pos_, orientation, nextMove.
Output: pos_ (the new position)
Saved Internal State: none
*/
QPointF translatePos(QPointF pos_, int32_t orientation, int32_t nextMove)
{
    if (nextMove == MOVE)
    {
        switch (orientation)
        {
        case LEFT:
            pos_.setX(pos_.x() - 1);
            break;
        case DOWN:
            pos_.setY(pos_.y() - 1);
            break;
        case RIGHT:
            pos_.setX(pos_.x() + 1);
            break;
        case UP:
            pos_.setY(pos_.y() + 1);
            break;
        default:
            ROS_ERROR("ERROR!! Orientation Not Valid.");
            break;
        }
        displayVisits(recVisit(orientation, true));
    }
    return pos_;
}

/*
Purpose: Change turtle's absolute orientation.
Input: orientation, nextMove.
Output: orientation (the new orientation)
Saved Internal State: none
*/
int32_t translateOrnt(int32_t orientation, int32_t nextMove)
{
    switch (nextMove)
    {
    case TURN_LEFT:
        if (orientation == LEFT)
        {
            orientation = UP;
        }
        else
        {
            orientation = orientation - 1;
        }
        break;
    case TURN_RIGHT:
        if (orientation == UP)
        {
            orientation = LEFT;
        }
        else
        {
            orientation = orientation + 1;
        }
        break;
    case MOVE:
        return orientation;
        break;
    case idle:
        return orientation;
        break;
    default:
        ROS_ERROR("ERROR!! Orientation Not Valid.");
        break;
    }
    return orientation;
}
