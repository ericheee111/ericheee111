/*
 * 18-642 Unit Testing Example
 * Example code by Milda Zizyte
 */

#include <iostream>
#include <cstdint>
#include <cstdlib>

enum state : int32_t
{
    INIT,
    turnRIGHT,
    turnLEFT,
    ErrorStateDefault
};

enum turtlestate : int32_t
{
    INIT1,
    RIGHT3,
    Goal,
    RIGHT2,
    RIGHT1,
    CALC_PATH,
    RIGHTturns,
    MOVEstate,
    LEFTturns,
    Turn_Right,
    Turn_Left,
    ErrorTurtleStateDefault
};

enum orientation : int32_t
{
    LEFT,
    DOWN,
    RIGHT,
    UP,
    ErrorOrientationDefault
};

enum turtleMove : int32_t
{
    MOVE,
    TURN_LEFT,
    TURN_RIGHT,
    idle,
    ErrorMoveDefault
};


std::pair<turtleMove, int32_t> calc_path(int32_t targetOri, int32_t currOri);

turtleMove studentTurtleStep1(bool end, int32_t targetOri, int32_t currOri, int32_t *turtleState);

int32_t recVisit(int32_t &newOrientation, bool move);


void ROS_ERROR(std::string e);