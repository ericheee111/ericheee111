/*
 * Code by Milda Zizyte
 *
 * This monitor checks that the invariant "turtle shall not move more
 * than on square at a time" is not violated.
 * It keeps track of the previous position of the turtle and compares it
 * to the current position to check the invariant.
 */

#include "monitor_interface.h"
 
// Keeps track of the last pose received
// moved is true if at least one pose has been received, false otherwise
static Pose last_pose;
static bool moved = false;
static Orientation last_orientation;

// Flag that doesn't print pose updates if the turtle has moved 0 steps
static const bool suppress_double_visits = true;

Orientation shouldFace(int x1, int y1, int x2, int y2)
{
    if (x1 == x2)
    {
        if (y1 < y2)
        {
            return SOUTH;
        }
        else
        {
            return NORTH;
        }
    }
    else
    {
        if (x1 < x2)
        {
            return EAST;
        }
        else
        {
            return WEST;
        }
    }
}

/*
 * Whenever the turtle moves, compare the current location
 * to the previous location and throw an invariant violation
 * if the locations differ by more than 1 in Manhattan Distance.
 */
void poseInterrupt(ros::Time t, int x, int y, Orientation o) {
  // Print pose info
  // Last conditional makes sure that if suppress_double_visits is
  // true, that the same pose isn't printed twice
  if (!suppress_double_visits || !moved ||
      (last_pose.x != x || last_pose.y != y)) {
    ROS_INFO("[[%ld ns]] 'Pose' was sent. Data: x = %d, y=%d", t.toNSec(), x, y);
  }

  

  // store last Pose in memory
  last_pose.x = x;
  last_pose.y = y;
  last_orientation = o;
  // Update this flag the first time the turtle moves
  if (!moved) {
    moved = true;
  }
}

/*
 * Empty interrupt handlers beyond this point
 */

void tickInterrupt(ros::Time t) {
}

void visitInterrupt(ros::Time t, int visits) {
}

void bumpInterrupt(ros::Time t, int x1, int y1, int x2, int y2, bool bumped) {
    ROS_INFO("[[%ld ns]] 'Bump' was called. check: x1 = %d, y1 = %d, x2 = %d, y2 = %d", t.toNSec(), x1, y1, x2, y2);
    Orientation o = shouldFace(x1, y1, x2, y2);
    if (o != last_orientation) {
        ROS_WARN("VIOLATION: Turtle is not facing the right direction! Expected %d, got %d", o, last_orientation);
    }
}

void atEndInterrupt(ros::Time t, int x, int y, bool atEnd) {
}
