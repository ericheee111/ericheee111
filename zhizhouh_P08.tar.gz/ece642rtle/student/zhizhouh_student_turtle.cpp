/*
 * Originally by Philip Koopman (koopman@cmu.edu)
 * and Milda Zizyte (milda@cmu.edu)
 *
 * STUDENT NAME: Zhizhou He
 * ANDREW ID: zhizhouh
 * LAST UPDATE: 10/28/2023
 *
 * This file is an algorithm to solve the ece642rtle maze
 * using the right-hand rule. The code is intentionaly right obfuscated.
 *
 */

#include "student.h"

/*
Purpose: Calculate how to turn to the target orientation.
Input: targetOri, currOri.
Output: std::pair<turtleMove, int>
Saved Internal State: none
*/
std::pair<turtleMove, int> calc_path(int targetOri, int currOri)
{
    int offset = 4;
    int diff = targetOri - currOri;
    if (diff < -2)
    {
        diff += offset;
    }
    else if (diff > 2)
    {
        diff -= offset;
    }

    if (diff < 0)
    {
        return {TURN_LEFT, abs(diff)};
    }
    else if (diff > 0)
    {
        return {TURN_RIGHT, diff};
    }
    else
    {
        return {MOVE, 0};
    }
}

/*
Purpose: Turtle determine next step.
Input: bumped, end, currState
Output: turtleMove (indicates the next step)
Saved Internal State: turtleState
*/
turtleMove studentTurtleStep1(bool end, int targetOri, int currOri, int *turtleState)
{
    turtleMove nextMove = idle;
    static int turnNeed = -1;
    std::pair<turtleMove, int> path;
    if (end == true)
    {
        *turtleState = Goal;
    }
    switch (*turtleState)
    {
    case INIT1:                         // S1
        *turtleState = RIGHT3;          // T1
        nextMove = TURN_RIGHT;
        break;
    case RIGHT3:                        // S2
        *turtleState = RIGHT2;          // T2
        nextMove = TURN_RIGHT;
        break;
    case Goal:                          // S3
        nextMove = idle;
        break;
    case RIGHT2:                        // S4
        *turtleState = RIGHT1;          // T3
        nextMove = TURN_RIGHT;
        break;
    case RIGHT1:                        // S5
        *turtleState = CALC_PATH;       // T4
        nextMove = TURN_RIGHT;
        break;
    case CALC_PATH:                     // S6
    {
        path = calc_path(targetOri, currOri);
        nextMove = path.first;
        turnNeed = path.second;
        if (nextMove == MOVE)
        {
            *turtleState = MOVEstate;   // T9
        }
        else if (nextMove == TURN_LEFT)
        {
            *turtleState = LEFTturns;   // T10
        }
        else if (nextMove == TURN_RIGHT)
        {
            *turtleState = RIGHTturns;  // T5
        }
        nextMove = idle;
        break;
    }
    case RIGHTturns:                    // S7
    {
        if (turnNeed > 0)
        {
            nextMove = idle;
            *turtleState = Turn_Right;  // T6
            turnNeed--;
        }
        else if (turnNeed == 0)
        {
            nextMove = idle;
            *turtleState = MOVEstate;   // T8
        }
        break;
    }
    case MOVEstate:                     // S8
    {
        nextMove = MOVE;
        *turtleState = INIT1;           // T14
        break;
    }
    case LEFTturns:                     // S9
    {
        if (turnNeed > 0)
        {
            nextMove = idle;
            *turtleState = Turn_Left;   // T11
            turnNeed--;
        }
        else if (turnNeed == 0)
        {
            nextMove = idle;
            *turtleState = MOVEstate;   // T13
        }
        break;
    }
    case Turn_Right:                // S10
    {
        nextMove = TURN_RIGHT;
        *turtleState = RIGHTturns;  // T7
        break;
    }
    case Turn_Left:                 // S11
    {
        nextMove = TURN_LEFT;
        *turtleState = LEFTturns;   // T12
        break;
    }
    default:
        ROS_ERROR("ERROR!! Invalid State.");
        break;
    }

    return nextMove;
}

/*
Purpose: Record the visits.
Input: newOrientation.
Output: visited times of the current location.
Saved Internal State: None
*/
int recVisit(int &newOrientation, bool move)
{
    const int arraySize = 23;
    const int initLocation = 11;
    static int visited[arraySize][arraySize] = {0};
    static int i = initLocation, j = initLocation;
    int peeki = i, peekj = j;

    switch (newOrientation)
    {
    case RIGHT:
        peekj--;
        if (move == true)
        {
            j--;
        }
        break;
    case DOWN:
        peeki++;
        if (move == true)
        {
            i++;
        }
        break;
    case LEFT:
        peekj++;
        if (move == true)
        {
            j++;
        }
        break;
    case UP:
        peeki--;
        if (move == true)
        {
            i--;
        }
        break;
    default:
        ROS_ERROR("ERROR!! Invalid Orientation.");
        break;
    }
    if (move == true)
    {
        visited[i][j]++;
        return visited[i][j];
    }
    return visited[peeki][peekj];
}
