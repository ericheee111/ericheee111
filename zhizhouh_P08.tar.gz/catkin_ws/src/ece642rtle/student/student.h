#include <ros/ros.h>
#include <boost/bind.hpp>
#include <ece642rtle/timeInt8.h>
#include <std_msgs/Empty.h>
#include <ece642rtle/RTIbump.h>
#include <ece642rtle/RTIatend.h>
#include <ece642rtle/PoseOrntBundle.h>
#include <ece642rtle/bumpEcho.h>
#include <ece642rtle/aendEcho.h>
#include <QPointF>
#include <cstdlib>

bool bumped(int x1, int y1, int x2, int y2);
bool atend(int x, int y);
void displayVisits(int visits);
bool moveTurtle(QPointF &pos_, int &newOrientation);

enum state : int
{
    INIT,
    turnRIGHT,
    turnLEFT
};

enum turtlestate : int
{
    INIT1,
    RIGHT3,
    Goal,
    RIGHT2,
    RIGHT1,
    CALC_PATH,
    RIGHTturns,
    MOVEstate,
    LEFTturns,
    Turn_Right,
    Turn_Left
};

enum orientation : int
{
    UP,
    RIGHT,
    DOWN,
    LEFT
};

enum turtleMove : int
{
    MOVE,
    TURN_LEFT,
    TURN_RIGHT,
    idle
};
QPointF translatePos(QPointF pos_, int orientation, int nextMove);
int translateOrnt(int orientation, int nextMove);
// turtleMove studentTurtleStep(bool bumped, bool end, int8_t *currState);
turtleMove studentTurtleStep1(bool end, int targetOri, int currOri, int *turtleState);
int recVisit(int &newOrientation, bool move);
