#!/bin/bash

cd ~/catkin_ws
catkin_make 
-DCATKIN_WHITELIST_PACKAGES="ece642rtle"
catkin_make


