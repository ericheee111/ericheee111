#!/bin/bash

source ~/catkin_ws/devel/setup.bash

sleep 2

cd ~/catkin_ws
catkin_make -DCATKIN_WHITELIST_PACKAGES="ece642rtle"

sleep 2
catkin_make


