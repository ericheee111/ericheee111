#!/bin/bash

cd ~/catkin_ws
source ~/catkin_ws/devel/setup.bash
catkin_make -DCATKIN_WHITELIST_PACKAGES="ece642rtle"
catkin_make


