#!/bin/bash

rm -rf catkin_ws/src/ece642rtle
rm -rf catkin_ws/src/proj1
rm -rf catkin_ws/src/beginner_tutorials
cp -r ece642rtle/ catkin_ws/src/
cp -r ece642rtle catkin_ws/src/ece642rtle

sleep 2

cd ~/catkin_ws
catkin_make -DCATKIN_WHITELIST_PACKAGES="ece642rtle"

sleep 2
catkin_make

catkin_make ece642rtle_student
